# Windows Golden Image (Home Lab)

## Features
- Unattended Windows install
- Chrome + Steam auto install
- GPU auto-detect install (NVIDIA/AMD/Intel)
- Logging enabled

## Usage
1. Copy autounattend.xml to USB/ISO root
2. Boot machine
3. Windows installs and configures automatically

## Structure
- autounattend.xml (main config)
- scripts (optional reference)

## Notes
Do NOT remove Edge, Media Features, or WebView in generator.
